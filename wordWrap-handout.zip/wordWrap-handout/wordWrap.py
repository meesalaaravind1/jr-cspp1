
def wordWrap(s,n):
	return ""
	

print(wordWrap(input(), int(input())))
