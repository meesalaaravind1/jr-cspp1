def readArray():
    l = input().split(" ")
    r = []
    for i in l:
    	r.append(int(i))
    return r

def repeatingPattern(l):
	return False



print(repeatingPattern(readArray()))


