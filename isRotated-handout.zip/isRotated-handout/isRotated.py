def rotateRight(s):
	return s[1:len(s)+1]

def isRotated(str1, str2):
	for i in range(str1):
		if(rotateRight(str1) == str2):
		return True
		return False

    

print(isRotated(input(), input()))
