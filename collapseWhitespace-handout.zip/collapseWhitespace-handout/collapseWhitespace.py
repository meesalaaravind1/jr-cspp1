def collapseWhitespace(s):
	return ""



print(collapseWhitespace(input()))
