def readArray():
    a = input().split(" ")
    l = []
    for i in a:
        l.append(int(i))
    return l

def multipolynomials(p1, p2):
    # Your code goes here
    return -1



print(multipolynomials(readArray(), readArray()))