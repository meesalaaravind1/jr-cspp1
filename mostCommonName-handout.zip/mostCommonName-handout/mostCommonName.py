def mostCommonName(a):
    return []


print(mostCommonName(input().split(" ")))