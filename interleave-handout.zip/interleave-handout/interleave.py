
def interleave(s1, s2):
	return ""

print(interleave(input(), input()))