def readArray():
	a = []
	l = int(input())
	for i in range(l):
		a.append(int(input()))
	return a

def moveToBack(a,b):
	# your code goes here
	return a


print(moveToBack(readArray(),readArray()))


