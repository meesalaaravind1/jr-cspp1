def readArray():
    n = int(input())
    l = []
    for i in range(n):
    	l.append(input())
    return l

def mostAnagrams(l):
	return ""




print(mostAnagrams(readArray()))


