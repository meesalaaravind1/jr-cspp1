def encodeOffset(s, d):
	return ""



print(encodeOffset(input(), int(input())))
