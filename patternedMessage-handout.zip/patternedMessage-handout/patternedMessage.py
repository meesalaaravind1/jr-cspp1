
def patternedMessage(s, p):
	return ""

print(patternedMessage(input(), input()))