def areAnagrams(s1, s2):
	return False



print(areAnagrams(input(), input()))
